#ifndef __IT_H__
#define __IT_H__

#include "main.h"
#include <stdint.h>

void prepare_data(void);
void send_data(void);

#endif
