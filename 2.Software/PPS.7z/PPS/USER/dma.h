#ifndef _DMA_H
#define _DMA_H

#include "stm32f10x.h" 
#include "main.h"
void Configure_DMA(void);


#endif




